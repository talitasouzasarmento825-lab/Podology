# Simulador de Podologia: Unha Encravada — V2

**Conteúdo**
- 3 casos: leve, moderado (granuloma), severo (bilateral).
- Sons (spray, corte, curativo), texturas, relatório final com nota e feedback.
- Funciona em desktop e mobile (iPhone via Safari ao hospedar).

## Como usar (GitHub Pages)
1) Envie todos os arquivos deste pacote para um repositório público.
2) Settings → Pages → Source: branch `main`, folder `/ (root)` → Save.
3) Acesse a URL `https://seuusuario.github.io/<nome-do-repo>/`.

> Protótipo educacional — não substitui orientação profissional.
